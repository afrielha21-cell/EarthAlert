
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => Array.from(root.querySelectorAll(s));
const E = (tag, attrs={}) => {const n=document.createElementNS('http://www.w3.org/2000/svg',tag);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,String(v)));return n;};
const safe = v => String(v??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(x,d=0)=>Number.isFinite(Number(x))?Number(x).toLocaleString('id-ID',{maximumFractionDigits:d,minimumFractionDigits:d}):'—';
const colors={A:'#168f84',B:'#e4a044',C:'#8976ca',D:'#d75e83',N:'#a8b5c0'};
const labels={A:'Dominan lebih dangkal',B:'P90 magnitudo lebih besar',C:'Kedalaman lebih besar',D:'Frekuensi gempa lebih tinggi',N:'Data terbatas'};
const SRC_BMKG='https://www.bmkg.go.id/gempabumi/mitigasi/antisipasi-gempabumi';
const SRC_BMKG_EDU='https://www.bmkg.go.id/gempabumi/mitigasi/edukasi-gempabumi-tsunami';
const BOX={L:91,R:144.5,B:-14,T:12.5,W:2200,H:1090};
const xp=lon=>(lon-BOX.L)/(BOX.R-BOX.L)*BOX.W,yp=lat=>(BOX.T-lat)/(BOX.T-BOX.B)*BOX.H;
const dist=(a,b,c,d)=>{const r=Math.PI/180,dy=(c-a)*r,dx=(d-b)*r,x=Math.sin(dy/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin(dx/2)**2;return 6371*2*Math.asin(Math.sqrt(Math.min(1,x)))};
const state={tab:'atlas',basemap:'ocean',mode:'clusters',cluster:'all',transparency:75,zones:true,markers:true,selected:null,scenario:'hunian',impactCase:null,tsCase:null,usgsRow:null,zoom:{x:0,y:0,w:BOX.W,h:BOX.H}};
let DS={};

const contextTypes={
  hunian:{name:'Rumah & hunian',description:'Untuk kejadian dengan kerusakan rumah atau perpindahan tempat tinggal. Prioritasnya keselamatan penghuni, pemeriksaan bangunan, dan pemulihan bertahap.',items:[['SEGERA','Jangan masuki bangunan rusak','Apabila terlihat retak besar, struktur miring, atau komponen runtuh, batasi akses dan tunggu pemeriksaan pihak berwenang.'],['SETELAH GEMPA','Dokumentasikan dan laporkan kerusakan','Catat lokasi, foto bagian terdampak jika aman, dan sampaikan ke perangkat setempat/BPBD untuk pendataan bantuan.'],['PEMULIHAN','Pemeriksaan teknis bangunan','Minta penilaian tenaga kompeten sebelum kembali dihuni, terutama pada elemen struktur dan sambungannya.'],['PERSIAPAN','Amankan benda non-struktural','Ikat lemari/rak, jauhkan benda berat dari jalur evakuasi, dan siapkan tas siaga keluarga.']]},
  sekolah:{name:'Sekolah & fasilitas publik',description:'Untuk bangunan pendidikan, tempat ibadah, pasar dan fasilitas umum. Fokusnya pemeriksaan kelayakan serta kesinambungan pelayanan.',items:[['SEGERA','Tutup sementara area yang rusak','Hentikan aktivitas di ruang yang memperlihatkan kerusakan hingga dinilai aman oleh pengelola dan tenaga teknis.'],['TINDAKAN','Periksa rute dan titik kumpul','Pastikan pintu, tangga, jalur keluar, serta titik berkumpul tidak terhalang puing atau material berbahaya.'],['OPERASIONAL','Siapkan layanan alternatif','Tentukan ruang belajar/ibadah/layanan sementara setelah koordinasi dengan pengelola dan pemerintah daerah.'],['PERSIAPAN','Latihan evakuasi terjadwal','Latih perlindungan diri saat guncangan dan evakuasi tertib, disesuaikan kebutuhan anak serta kelompok rentan.']]},
  kesehatan:{name:'Rumah sakit & layanan kesehatan',description:'Untuk kerusakan fasilitas kesehatan atau kejadian dengan korban luka. Fokusnya keselamatan pasien dan keberlanjutan layanan darurat.',items:[['SEGERA','Lakukan triase dan pertolongan','Utamakan pertolongan sesuai kemampuan dan hubungi layanan kedaruratan setempat.'],['TINDAKAN','Amankan bangunan dan alat berat','Periksa area berisiko, peralatan medis yang dapat terguling, instalasi listrik, gas, dan pasokan air.'],['PELAYANAN','Alihkan layanan bila diperlukan','Tentukan ruang/jejaring rujukan sementara sesuai keputusan pengelola fasilitas dan dinas kesehatan.'],['PERSIAPAN','Uji prosedur keselamatan fasilitas','Lakukan simulasi pelayanan ketika pasokan listrik/akses terganggu dan pastikan jalur pasien tersedia.']]},
  infrastruktur:{name:'Jalan, jembatan & akses',description:'Untuk catatan kerusakan ruas jalan, jembatan, bandara atau fasilitas penghubung. Jangan menggunakan tingkat magnitudo saja untuk memutuskan akses aman.',items:[['SEGERA','Hindari jalur yang tampak rusak','Jangan melintasi retakan, jembatan berubah bentuk, atau area dengan potensi reruntuhan sampai diperiksa petugas.'],['KOORDINASI','Laporkan titik dan jenis kerusakan','Sampaikan foto/koordinat kepada BPBD, dinas PU, atau pengelola sarana terkait bila aman untuk dilakukan.'],['PEMULIHAN','Siapkan rute dan akses alternatif','Prioritaskan akses ambulans, logistik, dan evakuasi; keputusan pembukaan kembali dilakukan oleh pengelola resmi.'],['PERSIAPAN','Periksa elemen vital berkala','Lakukan audit kondisi prasarana, sambungan struktur, dan kebutuhan penutupan operasional berdasarkan pedoman teknis.']]},
  pesisir:{name:'Pesisir & tsunami',description:'Panduan untuk lokasi pesisir apabila terjadi guncangan kuat/lama atau terdapat arahan resmi terkait tsunami. Status tsunami tidak ditentukan dari magnitudo saja.',items:[['SAAT TANDA ALAM','Segera evakuasi dari pesisir','Jika guncangan kuat/lama terasa di pantai atau air laut menunjukkan perubahan tidak biasa, menuju dataran tinggi atau jalur aman tanpa menunggu pesan aplikasi ini.'],['RESMI','Ikuti informasi InaTEWS/BMKG','Pastikan status dan area terdampak hanya berdasarkan informasi BMKG dan BPBD; jangan simpulkan tsunami dari warna klaster.'],['PERSIAPAN','Kenali jalur evakuasi setempat','Tentukan rute dan titik evakuasi resmi bersama BPBD, termasuk kebutuhan anak, lansia, dan penyandang disabilitas.'],['PASCA','Jangan kembali sebelum dinyatakan aman','Tsunami dapat memiliki beberapa gelombang. Ikuti pencabutan peringatan dan arahan resmi.']]},
  lereng:{name:'Lereng & tanah tidak stabil',description:'Untuk lokasi yang dilaporkan mengalami rekahan, longsor atau likuefaksi. Kondisi tanah tidak dapat dinilai hanya dari koordinat atau magnitudo.',items:[['SEGERA','Jauhi rekahan dan lereng labil','Hindari tebing, bidang longsoran, timbunan, dan area tanah bergerak yang bisa membahayakan.'],['PENANGANAN','Ikuti pembatasan lokasi berbahaya','Gunakan penilaian lapangan dari BPBD, PVMBG/geologi, dan petugas teknis untuk menentukan akses.'],['PEMULIHAN','Jangan membangun kembali tanpa kajian','Perlu kajian lokasi dan fondasi sesuai kondisi tanah dan pedoman daerah setempat.'],['PERSIAPAN','Kenali jalur evakuasi alternatif','Siapkan jalur yang tidak melalui kaki lereng curam, bantaran, atau kawasan reklamasi tidak stabil.']]},
};

function decideContext(caseRow){
  const t=caseRow?.context_tags||[];
  const found=[];
  if(t.includes('hunian')||t.includes('pengungsian'))found.push('hunian');
  if(t.includes('sekolah')||t.includes('fasilitas publik'))found.push('sekolah');
  if(t.includes('kesehatan')||t.includes('kedaruratan'))found.push('kesehatan');
  if(t.includes('infrastruktur'))found.push('infrastruktur');
  if(t.some(x=>x.includes('tsunami')))found.push('pesisir');
  if(t.some(x=>x.includes('likuifaksi')))found.push('lereng');
  return [...new Set(found.length?found:['hunian'])];
}
function eventContextHtml(c){
 const mag=Number(c.bmkg_magnitude),depth=Number(c.bmkg_depth_km),parts=[];
 if(Number.isFinite(mag)){
   parts.push(`Magnitudo katalog M ${fmt(mag,1)}: dipakai untuk mengenali skala kejadian, <b>bukan</b> menghitung tingkat kerusakan atau status peringatan secara otomatis.`);
 }
 if(Number.isFinite(depth)){
  if(depth<=70)parts.push(`Hiposenter sekitar ${fmt(depth,1)} km (gempa dangkal). Intensitas di permukaan tetap bergantung pada jarak, tanah, dan kerentanan bangunan.`);
  else if(depth<=300)parts.push(`Hiposenter sekitar ${fmt(depth,1)} km (kedalaman menengah). Klasifikasi ini tidak otomatis menunjukkan kerusakan lebih rendah atau lebih tinggi.`);
  else parts.push(`Hiposenter sekitar ${fmt(depth,1)} km (gempa dalam). Dampak setempat tidak dapat ditentukan hanya dari kedalaman.`);
 }
 if(c.impact_scope==='sequence')parts.push('Dampak yang tertulis berasal dari rangkaian gempa, sehingga tidak boleh dinisbatkan seluruhnya kepada satu titik/kejadian.');
 if((c.context_tags||[]).includes('kedaruratan'))parts.push('Terdapat laporan korban/luka: kesiapan pertolongan pertama dan akses layanan medis menjadi bagian dari mitigasi kontekstual.');
 return `<div class="pale-label">DASAR PEMILIHAN SARAN</div><div class="note">${parts.map(s=>`<p style="margin:0 0 5px">${s}</p>`).join('')}</div>`;
}
function caseAdviceHtml(c,{compact=false}={}){
  const contexts=decideContext(c),first=contexts[0];
  const m=Number(c.bmkg_magnitude);
  const magnitudeAction=Number.isFinite(m)?(m>=6.5?
    '<div class="note"><strong>Koordinasi dampak lintas wilayah:</strong> untuk kejadian bermagnitudo besar, cocokkan cakupan guncangan dan laporan dampak resmi sebelum menetapkan prioritas pemeriksaan fasilitas dan akses vital. Pantau informasi gempa susulan dari BMKG; bukan berarti seluruh wilayah pasti rusak.</div>':
    m>=5?'<div class="note"><strong>Pemeriksaan dampak setempat:</strong> cocokkan laporan kerusakan dan intensitas guncangan setempat dengan data BMKG/BPBD sebelum menentukan kebutuhan penutupan bangunan atau fasilitas.</div>':
    '<div class="note"><strong>Dampak aktual tetap menjadi acuan:</strong> walaupun magnitudo relatif lebih kecil, catatan kerusakan perlu ditindaklanjuti sesuai kondisi bangunan dan laporan otoritas, bukan diabaikan berdasarkan angka magnitudo.</div>') : '';

  const chunks=contexts.slice(0,compact?2:4).map(key=>{const x=contextTypes[key];return `<div class="advice-block"><h3>${safe(x.name)}</h3><ol class="case-recs">${x.items.slice(0,compact?2:3).map(item=>`<li><strong>${safe(item[1])}:</strong> ${safe(item[2])}</li>`).join('')}</ol></div>`}).join('');
  return `<div class="pale-label">ARAH MITIGASI SESUAI DAMPAK TERCATAT</div>${chunks}${magnitudeAction}<div class="note">Rekomendasi edukatif disusun dari <a href="${SRC_BMKG}" target="_blank" rel="noopener noreferrer">panduan BMKG</a>. Dampak aktual berbeda menurut jarak, intensitas guncangan, kondisi tanah, dan bangunan.</div>`;
}
function caseDetails(c,mini=false){
 const scope = c.impact_scope==='sequence'?'Dampak rangkaian gempa; bukan satu episenter':'Catatan kejadian pada katalog';
 return `<div class="overline">ARSIP BMKG · ${safe(c.bmkg_date?.slice(0,4)||'')}</div><h2>${safe(c.bmkg_place)}</h2><span class="pill">${safe(c.category)}</span>${c.impact_scope==='sequence'?'<span class="pill warning">DAMPAK RANGKAIAN</span>':''}
 <div class="fact-grid"><div class="fact"><label>MAGNITUDO BMKG</label><strong>M ${fmt(c.bmkg_magnitude,1)}</strong></div><div class="fact"><label>KEDALAMAN</label><strong>${fmt(c.bmkg_depth_km,1)} km</strong></div><div class="fact"><label>WAKTU KEJADIAN</label><strong>${safe(c.bmkg_date)}</strong></div><div class="fact"><label>KLASTER GRID</label><strong>${safe(c.cluster||'Tidak tersedia')}</strong></div></div>
 <div class="pale-label">DAMPAK YANG DICATAT</div><p>${safe(c.impact_summary)}</p>
 <div class="topic-tags">${(c.context_tags||[]).map(x=>`<span>${safe(x)}</span>`).join('')}</div><div class="note warn">${safe(scope)}. Informasi dampak bukan luaran K-Means.</div>
 ${eventContextHtml(c)} ${caseAdviceHtml(c,{compact:mini})}<div class="small-actions"><a class="action-link" target="_blank" rel="noopener noreferrer" href="${safe(c.bmkg_pdf_url)}">Halaman katalog BMKG ↗</a>${c.usgs_event_id?`<a class="action-link" target="_blank" rel="noopener noreferrer" href="https://earthquake.usgs.gov/earthquakes/eventpage/${encodeURIComponent(c.usgs_event_id)}/executive">USGS event ↗</a>`:''}</div><p class="case-source">Pemeriksaan lintas sumber dalam arsip proyek bersifat terbatas; gunakan katalog asli untuk verifikasi angka.</p>`;
}
function comparableCases({lat,lon,mag,depth,cluster},num=3){
 if(!Number.isFinite(lat)||!Number.isFinite(lon))return [];
 return DS.cases.map(c=>{
  const km=dist(lat,lon,Number(c.lat),Number(c.lon));
  const dm=Math.abs((mag??c.bmkg_magnitude)-c.bmkg_magnitude);
  const dd=Math.abs((depth??c.bmkg_depth_km)-c.bmkg_depth_km);
  let score=km/350+dm*1.4+Math.min(2,dd/120)+(cluster&&cluster===c.cluster?-0.55:0);
  return {c,score,km,dm};
 }).sort((a,b)=>a.score-b.score).slice(0,num);
}
function comparatorHtml(list){return `<div class="pale-label">KASUS HISTORIS PEMBANDING</div><p class="muted small">Contoh arsip dengan ciri lebih mirip menurut lokasi, magnitudo, kedalaman, dan klaster. <b>Tidak memprediksi dampak</b> pada titik terpilih.</p>${list.length?list.map(({c,km})=>`<div class="example-item"><button data-select-case="${safe(c.bmkg_catalog_id)}">${safe(c.bmkg_place)} · M ${fmt(c.bmkg_magnitude,1)} ↗</button><p>${safe(c.bmkg_date)} · ${fmt(km,0)} km jarak antar episenter</p></div>`).join(''):'<p class="muted">Belum ditemukan kasus pembanding.</p>'}`;}
function gridDetail(g){const c=labels[g.c]||'Tidak tersedia'; const cases=comparableCases({lat:g.y+.5,lon:g.x+.5,mag:g.m,depth:g.depth,cluster:g.c});
 return `<div class="overline">ANALISIS GRID 1° × 1°</div><h2>Wilayah ${fmt(g.y+.5,1)}°, ${fmt(g.x+.5,1)}°</h2><span class="pill">${safe(c)}</span>${g.c==='N'?'<span class="pill warning">Data terbatas</span>':''}<div class="fact-grid"><div class="fact"><label>JUMLAH GEMPA</label><strong>${fmt(g.n)}</strong></div><div class="fact"><label>MAGNITUDO P90</label><strong>${fmt(g.m,2)}</strong></div><div class="fact"><label>MEDIAN KEDALAMAN</label><strong>${fmt(g.depth,1)} km</strong></div><div class="fact"><label>MAGNITUDO MAKSIMUM</label><strong>M ${fmt(g.max,1)}</strong></div></div><div class="note">Grid berasal dari katalog regional historis 2016–2025. Warna menunjukkan kemiripan karakteristik seismik, bukan urutan tingkat bahaya.</div>${comparatorHtml(cases)}<div class="small-actions"><button class="plain-button" data-jump="mitigasi">Buka panduan mitigasi →</button></div>`;
}
function eventDetail(e){const same=DS.cases.find(x=>x.usgs_event_id===e.id);if(same)return caseDetails(same,true);
 let similar=comparableCases({lat:e.lat,lon:e.lon,mag:e.m,depth:e.dep,cluster:e.c});return `<div class="overline">EPISENTER HISTORIS USGS</div><h2>${safe(e.p)}</h2><div class="fact-grid"><div class="fact"><label>MAGNITUDO</label><strong>M ${fmt(e.m,1)} (${safe(e.mt)})</strong></div><div class="fact"><label>KEDALAMAN</label><strong>${fmt(e.dep,1)} km</strong></div><div class="fact"><label>TANGGAL UTC</label><strong>${safe(e.t)}</strong></div><div class="fact"><label>KOORDINAT</label><strong>${fmt(e.lat,2)}°, ${fmt(e.lon,2)}°</strong></div></div><div class="note warn">Tidak ada catatan kerusakan terverifikasi yang dipasangkan dengan ID ini di sampel BMKG. Jangan menafsirkan magnitudo sebagai ukuran kerusakan.</div>${comparatorHtml(similar)}<div class="small-actions"><a class="action-link" target="_blank" rel="noopener noreferrer" href="https://earthquake.usgs.gov/earthquakes/eventpage/${encodeURIComponent(e.id)}/executive">Detail USGS ↗</a></div>`;}

function drawAtlas(){
 const root=$('#atlasLayer');root.replaceChildren();$('#atlasRaster').setAttribute('href','assets/'+state.basemap+'.jpg');
 const zAlpha=(100-state.transparency)/100;
 if(state.mode==='clusters'){
  for(const g of DS.grids){if(state.cluster!=='all'&&g.c!==state.cluster)continue;
   const group=E('g',{'data-id':g.id,role:'button',tabindex:'0','aria-label':`Grid ${g.id}, klaster ${g.c}`}); const col=colors[g.c];
   if(state.zones){group.append(E('rect',{x:xp(g.x),y:yp(g.y+1),width:BOX.W/(BOX.R-BOX.L),height:BOX.H/(BOX.T-BOX.B),fill:col,'fill-opacity':zAlpha,stroke:'#fff','stroke-opacity':.5,'stroke-width':1.2}));}
   if(state.markers){const radius=Math.max(7,Math.min(20,6+Math.sqrt(g.n)*0.56));group.append(E('circle',{cx:xp(g.x+.5),cy:yp(g.y+.5),r:radius,fill:col,'fill-opacity':.92,stroke:'#fff','stroke-width':2}));}
   group.addEventListener('click',()=>showAtlasDetail(gridDetail(g))); group.addEventListener('keydown',ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();group.dispatchEvent(new Event('click'));}});root.append(group);
  }
 }else if(state.mode==='cases'){
  for(const c of DS.cases){const g=E('g',{role:'button',tabindex:'0','aria-label':c.bmkg_place});const r=6+Math.min(13,Math.max(0,(c.bmkg_magnitude-3)*3));const col=c.impact_scope==='sequence'?'#8a6479':'#d16a4e';g.append(E('circle',{cx:xp(c.lon),cy:yp(c.lat),r:r+5,fill:'#fff','fill-opacity':.63}));g.append(E('circle',{cx:xp(c.lon),cy:yp(c.lat),r,fill:col,'fill-opacity':.84,stroke:'#fff','stroke-width':3}));g.addEventListener('click',()=>showAtlasDetail(caseDetails(c,true)));g.addEventListener('keydown',e=>{if(e.key==='Enter')g.dispatchEvent(new Event('click'));});root.append(g);}
 }else{
  const filtered=DS.events.filter(e=>Number(e.m)>=5.5);
  for(const e of filtered){const g=E('g',{role:'button',tabindex:'0','aria-label':`M ${e.m}, ${e.p}`}),r=Math.max(4,Math.min(17,5+(e.m-5.5)*3));g.append(E('circle',{cx:xp(e.lon),cy:yp(e.lat),r,fill:colors[e.c]||'#1e7f8f','fill-opacity':.7,stroke:'#fff','stroke-width':1.5}));g.addEventListener('click',()=>showAtlasDetail(eventDetail(e)));g.addEventListener('keydown',v=>{if(v.key==='Enter')g.dispatchEvent(new Event('click'));});root.append(g);}
 }
 const isCluster=state.mode==='clusters';$('#cluster-filter').disabled=!isCluster;$('#zone-layer').disabled=!isCluster;$('#markers-layer').disabled=!isCluster;$('#alpha-range').disabled=!isCluster;
}
function showAtlasDetail(html){$('#atlasDetail').innerHTML=html;}
function applyZoom(){const z=state.zoom;$('#atlasMap').setAttribute('viewBox',`${z.x} ${z.y} ${z.w} ${z.h}`);}
function setZoom(factor,atX,atY){let z=state.zoom,cx=atX??(z.x+z.w/2),cy=atY??(z.y+z.h/2),w=Math.max(260,Math.min(BOX.W,z.w/factor)),h=Math.max(129,Math.min(BOX.H,z.h/factor));z.x=Math.max(0,Math.min(BOX.W-w,cx-(cx-z.x)*w/z.w));z.y=Math.max(0,Math.min(BOX.H-h,cy-(cy-z.y)*h/z.h));z.w=w;z.h=h;applyZoom();}
function setupMap(){const svg=$('#atlasMap');let initial=null;
 svg.addEventListener('pointerdown',e=>{if(e.target.closest('[role=button]'))return;svg.setPointerCapture(e.pointerId);initial={mouseX:e.clientX,mouseY:e.clientY,originX:state.zoom.x,originY:state.zoom.y,w:state.zoom.w,h:state.zoom.h};svg.classList.add('dragging');});
 svg.addEventListener('pointermove',e=>{if(!initial)return;const b=svg.getBoundingClientRect(),z=state.zoom;z.x=Math.max(0,Math.min(BOX.W-z.w,initial.originX-(e.clientX-initial.mouseX)*initial.w/b.width));z.y=Math.max(0,Math.min(BOX.H-z.h,initial.originY-(e.clientY-initial.mouseY)*initial.h/b.height));applyZoom();});
 const end=()=>{initial=null;svg.classList.remove('dragging')};svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end);svg.addEventListener('lostpointercapture',end);
 svg.addEventListener('wheel',e=>{e.preventDefault();const bounds=svg.getBoundingClientRect(),z=state.zoom,rx=(e.clientX-bounds.left)/bounds.width,ry=(e.clientY-bounds.top)/bounds.height;setZoom(e.deltaY<0?1.2:1/1.2,z.x+rx*z.w,z.y+ry*z.h);},{passive:false});
 $('#zoomPlus').addEventListener('click',()=>setZoom(1.4));$('#zoomMinus').addEventListener('click',()=>setZoom(1/1.4));$('#zoomHome').addEventListener('click',()=>{state.zoom={x:0,y:0,w:BOX.W,h:BOX.H};applyZoom()});
}
function navTo(tab){if(!$('#page-'+tab))tab='atlas';state.tab=tab;$$('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+tab));$$('[data-nav]').forEach(b=>b.classList.toggle('selected',b.dataset.nav===tab));history.replaceState(null,'','#'+tab);window.scrollTo({top:0,behavior:'instant'});}
function initAtlas(){
 $$('[data-nav]').forEach(b=>b.addEventListener('click',()=>navTo(b.dataset.nav)));
 $$('[data-basemap]').forEach(b=>b.addEventListener('click',()=>{state.basemap=b.dataset.basemap;$$('[data-basemap]').forEach(x=>x.classList.toggle('on',x===b));drawAtlas()}));
 $$('[data-mapmode]').forEach(b=>b.addEventListener('click',()=>{state.mode=b.dataset.mapmode;$$('[data-mapmode]').forEach(x=>x.classList.toggle('on',x===b));drawAtlas();if(state.mode==='cases')showAtlasDetail('<div class="overline">STUDI KASUS DAMPAK</div><h2>Pilih titik jingga untuk melihat arsip</h2><p class="muted">Titik jingga adalah gempa yang mempunyai catatan kerusakan terpilih dari katalog BMKG.</p>');}));
 $('#cluster-filter').addEventListener('change',e=>{state.cluster=e.target.value;drawAtlas()});
 $('#alpha-range').addEventListener('input',e=>{state.transparency=+e.target.value;$('#alpha-label').textContent=e.target.value+'%';drawAtlas()});
 $('#zone-layer').addEventListener('change',e=>{state.zones=e.target.checked;drawAtlas()});
 $('#markers-layer').addEventListener('change',e=>{state.markers=e.target.checked;drawAtlas()});
 document.addEventListener('click',e=>{const button=e.target.closest('[data-select-case]');if(button){const c=DS.cases.find(x=>x.bmkg_catalog_id===button.dataset.selectCase);if(c){state.impactCase=c;navTo('dampak');showImpactDetail(c);renderImpact();}return;}const jump=e.target.closest('[data-jump]');if(jump)navTo(jump.dataset.jump);});
 setupMap();drawAtlas();showAtlasDetail(gridDetail(DS.grids.find(g=>g.c==='B'&&g.n>=30)||DS.grids[0]));
}
function showImpactDetail(c){$('#impact-detail').innerHTML=caseDetails(c,false)}
function renderImpact(){const q=$('#impact-search').value.toLowerCase().trim(),year=$('#impact-year').value,cat=$('#impact-category').value;
 const arr=DS.cases.filter(c=>(year==='all'||c.bmkg_date.startsWith(year))&&(cat==='all'||cat===c.category)&&(!q||[c.bmkg_place,c.impact_summary,c.category,c.bmkg_date].join(' ').toLowerCase().includes(q)));
 $('#impact-count').textContent=`${arr.length} dari ${DS.cases.length} studi kasus yang ditampilkan`;
 $('#impact-list').innerHTML=arr.map(c=>`<button class="case-row ${state.impactCase?.bmkg_catalog_id===c.bmkg_catalog_id?'chosen':''}" data-impact-id="${safe(c.bmkg_catalog_id)}"><span class="case-date">${safe(c.bmkg_date)}</span><span><strong>${safe(c.bmkg_place)}</strong><small>${safe(c.category)} · ${safe(c.impact_scope==='sequence'?'Dampak rangkaian gempa':c.impact_summary.slice(0,68)+'…')}</small></span><span class="case-mag">${fmt(c.bmkg_magnitude,1)}</span></button>`).join('');}
function initImpact(){let years=[...new Set(DS.cases.map(c=>c.bmkg_date.slice(0,4)))].sort();years.forEach(y=>$('#impact-year').insertAdjacentHTML('beforeend',`<option value="${y}">${y}</option>`));let cats=[...new Set(DS.cases.map(c=>c.category))].sort();cats.forEach(x=>$('#impact-category').insertAdjacentHTML('beforeend',`<option value="${safe(x)}">${safe(x)}</option>`));['impact-search','impact-year','impact-category'].forEach(id=>$('#'+id).addEventListener(id==='impact-search'?'input':'change',renderImpact));$('#impact-list').addEventListener('click',e=>{let id=e.target.closest('[data-impact-id]')?.dataset.impactId;if(!id)return;let c=DS.cases.find(x=>x.bmkg_catalog_id===id);if(c){state.impactCase=c;showImpactDetail(c);renderImpact()}});state.impactCase=DS.cases.find(c=>c.bmkg_place.toLowerCase().includes('palu'))||DS.cases[0];showImpactDetail(state.impactCase);renderImpact();}
function renderMitigation(){const area=$('#scenario-content');const scenario=contextTypes[state.scenario];
 const examples=DS.cases.filter(c=>decideContext(c).includes(state.scenario)).slice(0,7);
 if(examples.length){const c=examples.find(x=>x.bmkg_catalog_id===state.mitigationCase?.bmkg_catalog_id)||examples[0];state.mitigationCase=c;$('#mitigation-case-detail').innerHTML=caseDetails(c,true);}
 area.innerHTML=`<div class="overline">PANDUAN BERDASARKAN KONDISI TERAMATI</div><h2 class="section-heading">${safe(scenario.name)}</h2><p class="lead">${safe(scenario.description)}</p><div class="recs-grid">${scenario.items.map(([step,title,desc])=>`<div class="rec-card"><span>${safe(step)}</span><h3>${safe(title)}</h3><p>${safe(desc)}</p></div>`).join('')}</div><div class="scenario-panel-title">STUDI KASUS BMKG YANG MEMILIKI KONTEKS SERUPA</div>${examples.length?examples.map(c=>`<div class="example-item"><button type="button" data-mit-id="${safe(c.bmkg_catalog_id)}">${safe(c.bmkg_place)} · ${safe(c.bmkg_date)} ↗</button><p>${safe(c.impact_summary).slice(0,130)}${c.impact_summary.length>130?'…':''}</p></div>`).join(''):'<p class="muted">Belum ada contoh yang cukup jelas pada sampel katalog.</p>'}`;
 }
function initMitigation(){const tabs=$('#scenario-tabs');Object.entries(contextTypes).forEach(([id,obj])=>{const btn=document.createElement('button');btn.textContent=obj.name;btn.dataset.scenario=id;btn.addEventListener('click',()=>{state.scenario=id;$$('[data-scenario]').forEach(b=>b.classList.toggle('on',b===btn));renderMitigation();});tabs.append(btn)});$$('[data-scenario]').forEach(b=>b.classList.toggle('on',b.dataset.scenario===state.scenario));$('#scenario-content').addEventListener('click',e=>{let id=e.target.closest('[data-mit-id]')?.dataset.mitId;if(!id)return;let c=DS.cases.find(x=>x.bmkg_catalog_id===id);state.mitigationCase=c;$('#mitigation-case-detail').innerHTML=caseDetails(c,true);});renderMitigation();}
function renderTsunami(){const f=$('#ts-filter').value,arr=DS.tsunami.filter(c=>f==='all'||c.cause_catalog===f);$('#ts-count').textContent=`${arr.length} dari ${DS.tsunami.length} catatan ditampilkan`;$('#ts-list').innerHTML=arr.map(c=>`<button class="case-row ${state.tsCase?.date_iso===c.date_iso?'chosen':''}" data-ts-id="${safe(c.date_iso+'|'+c.source_name)}"><span class="case-date">${safe(c.date_iso)}</span><span><strong>${safe(c.source_name)}</strong><small>${safe(c.cause_catalog)} · ${safe(c.impact_note||'Catatan historis')}</small></span><span class="case-mag">${c.magnitude_catalog!=null?fmt(c.magnitude_catalog,1):'—'}</span></button>`).join('');}
function tsDetail(c){return `<div class="overline">KATALOG TSUNAMI BMKG · ${c.year}</div><h2>${safe(c.source_name)}</h2><div class="fact-grid"><div class="fact"><label>PEMICU TERCATAT</label><strong>${safe(c.cause_catalog)}</strong></div><div class="fact"><label>MAGNITUDO PEMICU</label><strong>${c.magnitude_catalog!=null?'M '+fmt(c.magnitude_catalog,1):'Tidak tersedia'}</strong></div><div class="fact"><label>TANGGAL</label><strong>${safe(c.date_iso)}</strong></div><div class="fact"><label>ASAL SUMBER</label><strong>${safe(c.source_geography)}</strong></div></div><div class="pale-label">CATATAN SUMBER</div><p>${safe(c.impact_note||'Tidak ada uraian dampak pada arsip terpilih.')}</p><div class="note warn">Catatan kejadian historis; tidak menyatakan wilayah tsunami saat ini. Pencocokan USGS–BMKG dapat berstatus kandidat.</div><div class="pale-label">KONTEKS MITIGASI PESISIR</div><ol class="case-recs">${contextTypes.pesisir.items.map(i=>`<li><strong>${safe(i[1])}:</strong> ${safe(i[2])}</li>`).join('')}</ol><div class="small-actions"><a class="action-link" target="_blank" rel="noopener noreferrer" href="${safe(c.bmkg_pdf_page_link)}">Katalog BMKG ↗</a><a class="action-link" target="_blank" rel="noopener noreferrer" href="${SRC_BMKG_EDU}">Edukasi tsunami BMKG ↗</a></div>`;}
function initTsunami(){state.tsCase=DS.tsunami[0];$('#ts-detail').innerHTML=tsDetail(state.tsCase);$('#ts-filter').addEventListener('change',renderTsunami);$('#ts-list').addEventListener('click',e=>{const id=e.target.closest('[data-ts-id]')?.dataset.tsId;if(!id)return;const c=DS.tsunami.find(c=>c.date_iso+'|'+c.source_name===id);if(c){state.tsCase=c;$('#ts-detail').innerHTML=tsDetail(c);renderTsunami();}});renderTsunami();}
function filteredUSGSEvents(){
 const mag=Number($('#usgs-mag-filter')?.value||4),year=$('#usgs-year-filter')?.value||'all',sort=$('#usgs-sort-filter')?.value||'mag';
 let arr=DS.events.filter(e=>Number(e.m)>=mag&&(year==='all'||String(e.yr)===year));
 if(sort==='latest')arr.sort((a,b)=>String(b.t).localeCompare(String(a.t))||Number(b.m)-Number(a.m));
 else if(sort==='depth')arr.sort((a,b)=>Number(b.dep)-Number(a.dep)||Number(b.m)-Number(a.m));
 else arr.sort((a,b)=>Number(b.m)-Number(a.m)||Number(a.dep)-Number(b.dep));
 return arr;
}
function renderUSGSYears(){
 const root=$('#usgs-year-bars'); if(!root) return;
 const mag=Number($('#usgs-mag-filter')?.value||4),selected=$('#usgs-year-filter')?.value||'all';
 const years=Object.keys(DS.year).sort();
 const counts={}; years.forEach(y=>counts[y]=0);
 DS.events.filter(e=>Number(e.m)>=mag).forEach(e=>{const y=String(e.yr);counts[y]=(counts[y]||0)+1;});
 const max=Math.max(...Object.values(counts),1);
 root.innerHTML=years.map(y=>`<div class="year-col ${(selected===y||(selected==='all'&&y==='2019'))?'active':''}"><span class="year-num">${fmt(counts[y])}</span><div class="year-bar" style="height:${Math.max(18,(counts[y]/max)*280)}px"></div><small>${safe(y)}</small></div>`).join('');
}
function renderUSGS(){
 const arr=filteredUSGSEvents();
 renderUSGSYears();
 $('#usgs-count').textContent=`${fmt(arr.length)} kejadian memenuhi filter · menampilkan ${fmt(Math.min(120,arr.length))} teratas`;
 $('#usgs-table-wrap').innerHTML=`<table class="usgs-table"><thead><tr><th>Tanggal UTC</th><th>Magnitudo*</th><th>Kedalaman</th><th>Lokasi</th><th>Cluster grid</th><th>Detail</th></tr></thead><tbody>${arr.slice(0,120).map(e=>`<tr><td>${safe(e.t)}</td><td><strong>${fmt(e.m,1)}</strong> ${safe(e.mt||'')}</td><td>${fmt(e.dep,1)} km</td><td>${safe(e.p)}</td><td><span class="tag">${safe(e.c||'—')}</span></td><td><a target="_blank" rel="noopener noreferrer" href="https://earthquake.usgs.gov/earthquakes/eventpage/${encodeURIComponent(e.id)}/executive">USGS ↗</a></td></tr>`).join('')}</tbody></table><div class="table-note">* Riwayat USGS pada tab ini bersifat katalog historis. Daftar ini tidak mengubah hasil klastering, tidak menjadi label dampak, dan tidak dipakai sebagai penilaian kerusakan otomatis.</div>`;
}
function initUSGS(){
 const years=Object.keys(DS.year).sort();
 years.forEach(y=>$('#usgs-year-filter').insertAdjacentHTML('beforeend',`<option value="${safe(y)}">${safe(y)}</option>`));
 ['usgs-mag-filter','usgs-year-filter','usgs-sort-filter'].forEach(id=>$('#'+id).addEventListener('change',renderUSGS));
 renderUSGS();
}

function normalizeBMKGEntries(obj,forcedCategory){
 const feeds=obj?.feeds||(obj?.Infogempa?{[forcedCategory||'BMKG']:obj}:obj)||{};
 const flat=[];
 const mapCategory=(key)=>({gempa_terbaru:'Gempa terbaru',gempa_dirasakan:'Gempa dirasakan',dirasakan:'Gempa dirasakan',autogempa:'Gempa terbaru',m5:'M5+',m5_plus:'M5+'}[key]||key||forcedCategory||'BMKG');
 if(Array.isArray(feeds)) return feeds.map(e=>({...e,category:forcedCategory||e.category||'BMKG'}));
 for(const [cat,v] of Object.entries(feeds)){
  let payload=v?.Infogempa?.gempa ?? v?.gempa ?? v;
  let arr=Array.isArray(payload)?payload:[payload];
  arr.filter(Boolean).forEach(e=>flat.push({...e,category:mapCategory(cat)}));
 }
 return flat;
}
function renderBMKGRows(entries){
 const tbody=$('#bmkg-tbody');
 const cat=$('#bmkg-category')?.value||'gempa_terbaru';
 const labelMap={gempa_terbaru:'Gempa terbaru',gempa_dirasakan:'Gempa dirasakan',dirasakan:'Gempa dirasakan',autogempa:'Gempa terbaru',m5:'M5+',m5_plus:'M5+'};
 let arr=entries.filter(e=>{
  const name=String(e.category||'').toLowerCase();
  if(cat==='gempa_terbaru'||cat==='autogempa')return name.includes('terbaru')||name==='autogempa';
  if(cat==='gempa_dirasakan')return name.includes('dirasakan');
  if(cat==='m5')return name.includes('m5');
  return true;
 });
 if(!arr.length){tbody.innerHTML='<tr><td colspan="5">Belum ada data untuk kategori yang dipilih.</td></tr>';return;}
 tbody.innerHTML=arr.slice(0,120).map(e=>`<tr><td>${safe([e.Tanggal,e.Jam].filter(Boolean).join(' ' )||e.tanggal||'—')}</td><td><strong>${safe(e.Magnitude||e.magnitude||'—')}</strong></td><td>${safe(e.Kedalaman||e.kedalaman||'—')}</td><td>${safe(e.Wilayah||e.wilayah||'—')}</td><td>${safe(e.Potensi||e.Dirasakan||e.potensi||e.dirasakan||e.category||'—')}</td></tr>`).join('');
}
async function initBMKG(){
 const setMsg=(msg)=>$('#bmkg-update').textContent=msg;
 let entries=[];
 $('#bmkg-category').addEventListener('change',()=>renderBMKGRows(entries));
 $('#bmkg-fetch-btn').addEventListener('click',async()=>{
  setMsg('Memeriksa berkas snapshot BMKG yang tersedia pada hosting…');
  try{
    const r=await fetch('data/bmkg_snapshot.json?t='+Date.now(),{cache:'no-store'});
    if(!r.ok) throw new Error('Berkas snapshot tidak tersedia');
    const obj=await r.json();
    const fresh=normalizeBMKGEntries(obj);
    if(!fresh.length) throw new Error('Snapshot belum berisi kejadian');
    entries=fresh;renderBMKGRows(entries);
    setMsg('Snapshot tersimpan berhasil dimuat (pembaruan: '+(obj.fetched_at_utc||'belum diketahui')+'). Status ini bukan feed langsung dari BMKG.');
  }catch(err){setMsg('Belum ada snapshot yang tersedia pada hosting. Impor berkas JSON resmi BMKG atau buka portal BMKG. '+err.message);}
});
 $('#bmkg-import').addEventListener('change',async(ev)=>{const f=ev.target.files?.[0]; if(!f) return; try{const obj=JSON.parse(await f.text()); entries=normalizeBMKGEntries(obj,$('#bmkg-category').selectedOptions[0]?.textContent||'BMKG'); renderBMKGRows(entries); setMsg(`Berhasil mengimpor ${entries.length} entri dari file JSON lokal.`);}catch(err){setMsg('File JSON tidak dapat dibaca. Pastikan format mengikuti struktur BMKG Open Data.');}});
 try{const r=await fetch('data/bmkg_snapshot.json',{cache:'no-store'}); if(!r.ok) throw new Error('Tidak ada snapshot'); const obj=await r.json(); entries=normalizeBMKGEntries(obj); if(!entries.length) throw new Error('Snapshot kosong'); renderBMKGRows(entries); setMsg('Snapshot BMKG tersedia (pembaruan: '+(obj.fetched_at_utc||'belum diketahui')+'). Pilih kategori atau impor JSON bila diperlukan.'); }catch(err){ renderBMKGRows([]); setMsg('Snapshot BMKG belum tersedia pada hosting. Jalankan skrip pembaruan atau impor JSON resmi BMKG.'); }
}
function renderMetrics(){
 const root=$('#metric-chart');
 const pts=DS.metrics.map(m=>({k:Number(m.k),w:Number(m.w)}));
 const minW=Math.min(...pts.map(p=>p.w)), maxW=Math.max(...pts.map(p=>p.w));
 const W=760,H=220,padL=42,padR=24,padT=16,padB=34;
 const X=k=>padL+((k-1)/(pts.length-1))*(W-padL-padR);
 const Y=w=>padT+((maxW-w)/(maxW-minW||1))*(H-padT-padB);
 const path=pts.map((p,i)=>`${i?'L':'M'} ${X(p.k).toFixed(1)} ${Y(p.w).toFixed(1)}`).join(' ');
 const circles=pts.map(p=>`<circle cx="${X(p.k).toFixed(1)}" cy="${Y(p.w).toFixed(1)}" r="${p.k===4?7:5}" fill="${p.k===4?'#d8a052':'#4d93ad'}"></circle>`).join('');
 const labels=pts.map(p=>`<text x="${X(p.k).toFixed(1)}" y="${H-8}" text-anchor="middle" font-size="11" fill="#5f7787">k=${p.k}</text>`).join('');
 const k4=pts.find(p=>p.k===4);
 root.innerHTML=`<div class="elbow-wrap"><svg class="elbow-svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="Grafik elbow K-Means"><path d="${path}" fill="none" stroke="#2f89a3" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"></path>${circles}<text x="${X(4)-38}" y="${Y(k4.w)-14}" font-size="12" font-weight="700" fill="#b87422">Elbow k=4</text>${labels}</svg><div class="elbow-note">Kurva WCSS menurun tajam dari <strong>k=1</strong> sampai <strong>k=4</strong>, lalu mulai melandai. Karena itu, titik siku dipertahankan pada <strong>k=4</strong>.</div></div>`;
}
async function boot(){try{
 const names=['grids','events','cases','tsunami','metrics','profiles','year','metadata'];const files=await Promise.all(names.map(async n=>{const r=await fetch(`data/${n}.json`);if(!r.ok)throw new Error(`Berkas ${n}.json tidak dapat dimuat.`);return r.json()}));names.forEach((n,i)=>DS[n]=files[i]);
 initAtlas();initUSGS();initImpact();initMitigation();initTsunami();initBMKG();renderMetrics();navTo(location.hash.replace('#','')||'atlas');
 }catch(err){const s=$('#site-status');s.textContent='Data belum berhasil dimuat: '+err.message+' Jalankan situs melalui server HTTP (atau deploy), jangan membuka index.html langsung dengan file://';s.className='site-status visible error';console.error(err);}}
boot();
