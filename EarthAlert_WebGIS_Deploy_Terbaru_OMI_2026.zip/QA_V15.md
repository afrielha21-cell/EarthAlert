# EarthAlert V15 — Pengujian dan batasan

**Status:** proyek WebGIS statis siap untuk uji deploy; **belum dipublikasikan ke domain publik**.

## Pemeriksaan sumber data (dibaca dari arsip proyek V12)
- 18.326 entri USGS pada cakupan regional analisis (2016–2025)
- 457 grid 1°; 292 memiliki label A/B/C/D, 165 tidak memiliki label klaster karena data terbatas
- 42 studi kasus terpilih BMKG–USGS, termasuk catatan dampak rangkaian gempa yang dipisahkan
- 12 catatan tsunami historis BMKG terpilih
- Model K-Means k=4 dari V8 dipertahankan, **bukan model baru yang dilatih di V15**

## Pengujian browser
Pengujian HTML+CSS+JS dengan data lokal yang dibundel ke browser pengujian Chromium (karena browser pengujian di lingkungan ini membatasi navigasi localhost/file):
- Render 457 grid dan klik fitur: berhasil
- Ubah mode peta → 42 titik dampak: berhasil
- Klik titik dampak → detail panel: berhasil
- Filter dampak `Palu` → 1 kasus: berhasil
- Pilih kategori `Jalan, jembatan & akses` → rekomendasi berubah: berhasil
- Arsip tsunami 12 entri dan filter: berhasil
- Navigasi Metodologi/Informasi BMKG: berhasil
- Tampilan mobile 390 px: tidak terjadi horizontal overflow
- Kesalahan JavaScript pada pengujian: 0

Tampilan Ocean/Satelit bersumber dari aset NASA Blue Marble dan NOAA ETOPO yang dibundel; mereka bukan API eksternal. Semua teks menggunakan CSS `font-family:Poppins`, dengan font web Google dan fallback sistem jika font eksternal tidak tersedia.

## Belum dilakukan
- Pengujian deployment aktual GitHub Pages/Netlify (memerlukan akun/hosting pengguna)
- Uji berhasilnya fetch berkala ke BMKG pada Actions di produksi; aplikasi akan menyatakan **belum tersinkron** selama belum ada hasil resmi
- Validasi independen seluruh 42 kasus dan padanan lintas sumber di luar audit arsip V12
- Penghitungan/validasi tingkat risiko berbasis bangunan, kerentanan, paparan penduduk, atau shaking map

## Etika dan keselamatan
Rekomendasi mitigasi berupa panduan edukasi berbasis dampak yang **tercatat** dari katalog dan aturan yang dapat ditelusuri. Kerusakan pada lokasi baru tidak ditentukan dengan menyalin dampak historis. Untuk peringatan aktual/evakuasi ikuti BMKG dan BPBD setempat.
