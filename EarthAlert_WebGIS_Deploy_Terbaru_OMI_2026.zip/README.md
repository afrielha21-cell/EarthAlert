# EarthAlert V15 — Public WebGIS & Contextual Mitigation

EarthAlert is a **public static research and education WebGIS**. It runs on a basic HTTPS static hosting service and does **not require an API key or a database**. The model and data are carried forward from the research team's V8–V12 materials; **V15 does not retrain K-Means**.

## What is included

- **Atlas ML:** 457 observed geographic 1° grids, of which 292 have a K-Means k=4 label. Variables: observed event count, P90 magnitude, median focal depth. **Default grid fill is 75% transparent (25% opacity)**.
- **Basemap:** NOAA ETOPO relief ocean / NASA Blue Marble imagery baked locally as `.jpg` (no external tile service, no API key). Source images were prepared in the earlier V8 prototype, which bundled NASA/NOAA reference imagery via Python Basemap. Provide attribution. Check imagery use guidelines before publication, especially if planned for promotional/commercial use.
- **Impact casework:** 42 selected BMKG significant/damaging earthquake case notes, many matched to USGS identifiers. These are **not all damaging earthquakes** in the period. Damage from earthquake sequences is kept as a sequence and should not be assigned to just one epicenter.
- **Contextual mitigation:** rule-based editorial recommendations based on actual *documented case impacts* (homes, schools, health facilities, road/bridge infrastructure, tsunamis, liquefaction). They **are not outputs of clustering**, predictions of damage, or emergency orders.
- **Tsunami archive:** 12 catalog examples, with trigger and source status. The matching of some tsunami cases to USGS is still unverified.
- **BMKG information:** the scheduled build fetches latest official JSON snapshots and keeps the last good snapshot. The timestamp is shown to readers. No snapshot is shipped as live data by default.

## Local preview (important)

Do not open `index.html` directly with the `file://` protocol: the browser blocks JSON fetches. Instead, open a terminal inside this folder and run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`. Alternatively, open with the VS Code **Live Server** extension.

## Public deployment — GitHub Pages (recommended)

1. Create a **public GitHub repository** (for example `earthalert-webgis`).
2. **Upload the contents of this folder to the repository root** (not the parent ZIP or the folder itself). Make sure `index.html`, `styles.css`, `app.js`, `data/`, `assets/`, `scripts/`, and `.github/workflows/deploy.yml` are present. GitHub web upload may omit hidden `.github` directory; use Git to preserve it.
3. Use default branch `main`. Under **Settings → Pages → Build and deployment**, choose **GitHub Actions**.
4. Open **Actions**, run `Publish EarthAlert public WebGIS` once via `workflow_dispatch`. It also runs on push to `main` and attempts a BMKG snapshot refresh every 3 hours (best effort, times are not guaranteed).
5. The site URL will be of the form `https://<account>.github.io/<repository>/`. Paths in the app are relative to the site root so repository subpaths work.
6. Optionally connect a custom domain, enable HTTPS, and cross-check that BMKG status shows a real timestamp rather than a placeholder.

The uploaded ZIP **is not automatically online**. Uploading to a hosting provider or GitHub repository and enabling Pages requires account access, which is not included in this deliverable.

## Other hosting options

Upload the same static directory to Netlify / Cloudflare Pages / Vercel as a static site. Without a scheduled GitHub Actions build, the BMKG snapshot will not refresh automatically unless equivalent scheduling is configured. The atlas and contextual mitigation pages work without network APIs once hosted.

## Source credits & scientific limits

- USGS Earthquake FDSN Event Catalog: https://earthquake.usgs.gov/fdsnws/event/1/
- BMKG Open Data: https://data.bmkg.go.id/gempabumi/
- BMKG earthquake precautions: https://www.bmkg.go.id/gempabumi/mitigasi/antisipasi-gempabumi
- BMKG tsunami/gempa education: https://www.bmkg.go.id/gempabumi/mitigasi/edukasi-gempabumi-tsunami
- BMKG significant damaging-earthquake and tsunami catalog PDF page anchors are retained in each case record.
- NOAA ETOPO global relief: https://www.ncei.noaa.gov/products/etopo-global-relief-model
- NASA imagery guidelines: https://www.nasa.gov/nasa-brand-center/images-and-media/

**Limitations:** The 2016–2025 dataset is a regional approximation and contains events beyond sovereign Indonesia. Event frequency changes with catalog completeness and aftershock sequences. The model separates activity characteristics, **not earthquake hazard / human risk**. Magnitude (`mb`, `Mw`, etc.) must not be treated as directly interchangeable. Earthquake damage depends on shaking, distance, soil, and building construction; avoid inferring actual damage using magnitude alone.

## Data directory

| File | Purpose |
|---|---|
| `data/events.json` | 18,326 USGS regional events and associated grid labels |
| `data/grids.json` | 457 grid summaries (292 assigned clusters) |
| `data/cases.json` | 42 cases with source references and editorial context tags |
| `data/tsunami.json` | 12 selected BMKG tsunami records |
| `data/metrics.json` | Elbow and Silhouette model metrics |
| `data/bmkg_snapshot.json` | Official latest-event snapshot when deployment refresh succeeds |

**Do not use the case list for automated damage-risk scoring without a separately validated supervised model and exposure data.**
