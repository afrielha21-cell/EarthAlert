# Deploy EarthAlert versi revisi publik

**Folder ini (`05_WEBGIS_PUBLIK_SIAP_DEPLOY`) adalah ROOT situs**. Isinya `index.html`, `styles.css`, `app.js`, `data/`, `assets/`, `.github/workflows/deploy.yml`, dan `scripts/sync_bmkg.py`.

### Uji lokal
Masuk ke folder ini lalu jalankan:
```bash
python -m http.server 8000
```
Buka `http://localhost:8000`. Membuka `index.html` via `file://` tidak bisa mengambil file JSON karena pembatasan browser.

### GitHub Pages
1. Buat repo publik GitHub; unggah **ISI** folder ini ke root repo, termasuk `.github` (gunakan Git CLI untuk folder tersembunyi).
2. Pastikan branch `main`; pada Settings → Pages atur Source menjadi **GitHub Actions**.
3. Jalankan workflow **Publish EarthAlert public WebGIS** pada tab Actions untuk deploy pertama kali; perubahan di branch `main` juga memicu deploy.
4. Workflow mencoba memperbarui `data/bmkg_snapshot.json` sebelum deploy dan secara periodik. Kalau gagal, konten lama atau placeholder yang jujur akan ditampilkan.
5. Situs terbuka publik setelah akun pemilik repo mengaktifkan Pages. Belum ada deployment publik yang dilakukan oleh pembuatan paket ini.

### Tab Informasi BMKG
Pilihan `Ambil snapshot terbaru` membaca ulang JSON hasil sinkronisasi **dari hosting**, bukan permintaan live ke layanan BMKG via browser (yang dapat terkendala CORS). Alternatif: impor JSON resmi secara manual. Data belum tersedia sebelum sinkronisasi sukses.

### Cakupan dan keterbatasan
Model berasal dari V8 (tidak dilatih ulang). Peta hanya menggambarkan karakteristik rekaman gempa; bukan zona risiko resmi. Data USGS 2016–2025 bersifat regional; 42 contoh kerusakan BMKG dan 12 contoh tsunami bukan katalog lengkap. Tab NOAA adalah tautan ke https://www.ncei.noaa.gov/maps/hazards/; data NOAA **belum tergabung dalam model**.

**Regenerasi data:** `scripts/build_data.py` dipertahankan sebagai kode arsip dan mengharapkan file V12 pada folder master di atas folder situs. Tidak diperlukan untuk deployment harian; jangan dijalankan di hosting jika hanya folder situs diunggah.
