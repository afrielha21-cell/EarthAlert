"""Export a single-file demo that runs from file:// without a local web server.
The deployment source remains index.html+data+assets for maintainability.
"""
from pathlib import Path
import base64,json
root=Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text(encoding='utf-8')
css=(root/'styles.css').read_text(encoding='utf-8')
js=(root/'app.js').read_text(encoding='utf-8')
html=html.replace('<link rel="stylesheet" href="styles.css"/>','<style>'+css+'</style>')
html=html.replace('<script src="app.js" defer></script>','')
data={f'data/{f.name}':json.loads(f.read_text()) for f in (root/'data').glob('*.json')}
assets={k:'data:image/jpeg;base64,'+base64.b64encode((root/'assets'/f'{k}.jpg').read_bytes()).decode() for k in ('ocean','satellite')}
# Override the file asset path with embedded images for the standalone demo.
js=js.replace("'assets/'+state.basemap+'.jpg'", "ASSET_URIS[state.basemap]")
shim='const ASSET_URIS='+json.dumps(assets)+';const STATIC_DATA='+json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')+';window.fetch=(url)=>Promise.resolve({ok:Object.prototype.hasOwnProperty.call(STATIC_DATA,String(url)),json:async()=>STATIC_DATA[String(url)]});'
# Keep source order. Font stylesheet remains an optional network resource with local CSS fallback.
html=html.replace('<image id="atlasRaster" x="0" y="0" width="2200" height="1090" preserveAspectRatio="none" href="assets/ocean.jpg"/>','<image id="atlasRaster" x="0" y="0" width="2200" height="1090" preserveAspectRatio="none" href="'+assets['ocean']+'"/>')
html=html.replace('</body>','<script>'+shim+'</script><script>'+js+'</script></body>')
(root.parent/'EarthAlert_V15_Demo_Standalone.html').write_text(html,'utf-8')
print('Demo file size',len(html)/1024/1024,'MiB')
