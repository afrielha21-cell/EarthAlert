"""Build the public web dataset from the audited V12 HTML artifact.
The script keeps source records separate from editorial mitigation rules.
"""
from pathlib import Path
from bs4 import BeautifulSoup
import base64, json, re
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT.parent/'03_KODE_PENGOLAHAN'/'ARSIP_V12_SITUS_SEBAGAI_INPUT_DATA.html'
b=BeautifulSoup(SRC.read_text(encoding='utf-8'),'html.parser')
scripts=[x.text for x in b.find_all('script')]
dec=json.JSONDecoder()
def decode(s,needle):
 ix=s.index(needle)+len(needle)
 return dec.raw_decode(s[ix:])[0]
grids=decode(scripts[0],'GRIDS=')
events=decode(scripts[0],',EV=')
metrics=decode(scripts[0],',METRICS=')
profiles=decode(scripts[0],',PROF=')
year=decode(scripts[0],',YEAR=')
cases=decode(scripts[1],'const cases=')
tsunamis=decode(scripts[2],'const data=')
for case in cases:
 text=(case.get('impact_summary','')+' '+case.get('bmkg_place','')).lower()
 tags=[]
 if any(x in text for x in ['rumah','permukiman','hunian']): tags.append('hunian')
 if any(x in text for x in ['sekolah','pendidikan']): tags.append('sekolah')
 if any(x in text for x in ['rumah sakit','fasilitas kesehatan']): tags.append('kesehatan')
 if any(x in text for x in ['jembatan','jalan','infrastruktur','bandara']): tags.append('infrastruktur')
 if any(x in text for x in ['tempat ibadah','masjid','gereja']): tags.append('fasilitas publik')
 if any(x in text for x in ['pasar','pusat perbelanjaan','perkantoran']): tags.append('fasilitas publik')
 if any(x in text for x in ['luka','korban meninggal','korban jiwa']): tags.append('kedaruratan')
 if 'tsunami' in text: tags.append('tsunami tercatat pada catatan kasus')
 if 'likuifaksi' in text: tags.append('likuifaksi tercatat pada catatan kasus')
 if 'mengungsi' in text: tags.append('pengungsian')
 if not tags: tags.append('evaluasi pascagempa')
 case['context_tags']=tags
 case['source_type']='BMKG catalog; USGS event match in project audit'
 (ROOT/'data'/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,separators=(',',':')),'utf-8')
for name, obj in [('grids.json',grids),('events.json',events),('tsunami.json',tsunamis),('metrics.json',metrics),('profiles.json',profiles),('year.json',year)]:
 (ROOT/'data'/name).write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')),'utf-8')
for id in ['ocean','satellite']:
 tag=b.find('image',{'id':id})
 uri=tag['href']; (ROOT/'assets'/f'{id}.jpg').write_bytes(base64.b64decode(uri.split(',',1)[1]))
meta={'event_count':len(events),'grid_count':len(grids),'labeled_grids':sum(c['c']!='N' for c in grids),'case_count':len(cases),'tsunami_count':len(tsunamis),'source':'EarthAlert V12 source archive; original measurements from USGS/BMKG','period':'2016-2025','model':'K-Means k=4, V8 baseline; no retraining in V15','baseline':'Dataset 18,326 regional events (coastal proximity approximation); not a national census or hazard map', 'comparison':'Damage/tsunami sample is a separate layer and not used to fit clustering.'}
(ROOT/'data'/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),'utf-8')
print(meta)
